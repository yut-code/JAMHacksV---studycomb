var objPeople = [
  {
    username:"Clara"
    password:"pass1"
  },
  {
    username:"Teresa"
    password:"pass2"
  },
  {
    username:"Omar"
    password:"pass3"
  },
  {
    username:"Gabe"
    password:"pass4"
  }
]

//login functionality
function login() {
//retrieve data input from the from
var username=document.getElementById()
}